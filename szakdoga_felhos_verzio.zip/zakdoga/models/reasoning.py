import json
import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

DATA_DIR = "data"

def load_json(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Hiba: {file_path} nem található!")
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def extract_relevant_data(comments, sentiment_results, bot_results):
    combined = []
    for c, s, b in zip(comments, sentiment_results, bot_results):
        combined.append({
            "comment": c,
            "sentiment": s.get("prediction", "N/A"),
            "bot": b.get("prediction", "N/A")
        })
    return combined

def generate_prompt(combined_data):
    sample_str = "\n".join(
        [f"- \"{item['comment']}\" | Sentiment: {item['sentiment']} | Bot: {item['bot']}" for item in combined_data[:30]]  # max 30 komment, hogy ne legyen túl hosszú
    )

    prompt = f"""
Analyze the following YouTube comments and their metadata:
- What are the main topics that emerge?
- Is the overall sentiment positive, negative, or mixed?
- How credible are these comments (based on bot detection)?
- Are there any recurring trends or patterns?

Comment data:
{sample_str}

Please provide a well-structured summary!
"""
    return prompt.strip()

def query_local_llm(prompt, model_id="tiiuae/falcon-7b-instruct"):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.float16)
    model.to(device)

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=4096)
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=512,
            temperature=0.7,
            top_p=0.95,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id
        )

    response = tokenizer.decode(output[0], skip_special_tokens=True)
    # csak a válasz utolsó részét vágjuk ki, ha benne marad a prompt
    return response.split("Comment data:")[-1].strip()

def save_summary(summary, output_path):
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({"summary": summary}, f, indent=4, ensure_ascii=False)
    print(f"Összegzés mentve: {output_path}")

def summarize_comments(sentiment_path, bot_path, output_path="data/summary.json"):
    comments = load_json(os.path.join(DATA_DIR, "comments.json"))
    sentiment_results = load_json(sentiment_path)
    bot_results = load_json(bot_path)

    combined = extract_relevant_data(comments, sentiment_results, bot_results)
    prompt = generate_prompt(combined)
    summary = query_local_llm(prompt)

    save_summary(summary, output_path)
    return summary

if __name__ == "__main__":
    summarize_comments("data/sentiment_results.json", "data/bot_detection_results.json")
    print("Reasoning CUDA LLM sikeresen lefutott!")
