import os
import json

# Modulfunkciók importálása
from models.sentiment_analysis import sentiment_analysis as analyze_sentiment
from models.bot_detection_modell import detect_bots
from models.reasoning import summarize_comments

# Adatmappa
DATA_DIR = "data"

# Fájl elérési utak
COMMENTS_PATH = os.path.join(DATA_DIR, "comments.json")
SENTIMENT_PATH = os.path.join(DATA_DIR, "sentiment_results.json")
BOT_RESULTS_PATH = os.path.join(DATA_DIR, "bot_detection_results.json")
SUMMARY_PATH = os.path.join(DATA_DIR, "summary.json")

# JSON fájl betöltése
def load_json(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Hiba a(z) {filepath} beolvasásakor: {e}")
        return None

def main():
    print("Social Media Filter elindult CUDA LLM-mel...\n")

    # Kommentek betöltése
    comments_data = load_json(COMMENTS_PATH)
    if comments_data is None:
        print("Nem sikerült betölteni a kommenteket!")
        return

    # Sentiment analízis
    try:
        analyze_sentiment(COMMENTS_PATH, SENTIMENT_PATH)
        sentiment_result = load_json(SENTIMENT_PATH)
        print("\n✅ Sentiment analízis sikeres.")
    except Exception as e:
        print("\n❌ Hiba a sentiment analízis során:", str(e))
        return

    # Bot detekció
    try:
        detect_bots(COMMENTS_PATH, BOT_RESULTS_PATH)
        bot_result = load_json(BOT_RESULTS_PATH)
        print("\n✅ Bot detekció sikeres.")
    except Exception as e:
        print("\n❌ Hiba a bot detekció során:", str(e))
        return

    # Reasoning összegzés
    try:
        summarize_comments(SENTIMENT_PATH, BOT_RESULTS_PATH, SUMMARY_PATH)
        print("\n✅ Összegzés sikeres. Eredmény elmentve:", SUMMARY_PATH)
    except Exception as e:
        print("\n❌ Hiba az összegzés során:", str(e))
        return

    print("\n🎉 Minden lépés sikeresen lefutott!")

if __name__ == "__main__":
    main()
