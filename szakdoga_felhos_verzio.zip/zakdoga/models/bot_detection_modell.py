import json
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

def detect_bots(input_path="data/comments.json", output_path="data/bot_detection_results.json", batch_size=32):
    import json
    import torch
    from transformers import AutoTokenizer, AutoModelForSequenceClassification

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    MODEL_NAME = "tdrenis/finetuned-bot-detector"
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)
    model.to(device)

    with open(input_path, "r", encoding="utf-8") as f:
        comments = json.load(f)

    if not isinstance(comments, list):
        raise ValueError("A comments.json fájl nem listát tartalmaz!")

    labels = ["human", "bot"]
    results = []

    for i in range(0, len(comments), batch_size):
        batch_comments = comments[i:i+batch_size]
        inputs = tokenizer(batch_comments, padding=True, truncation=True, return_tensors='pt')
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = model(**inputs)
            predictions = torch.argmax(outputs.logits, dim=-1)

        batch_results = [
            {"comment": comment, "prediction": labels[pred.item()]}
            for comment, pred in zip(batch_comments, predictions)
        ]
        results.extend(batch_results)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=4, ensure_ascii=False)

    print(f"✅ Bot detekció mentve: {output_path}")
    return results
    
detect_bots()